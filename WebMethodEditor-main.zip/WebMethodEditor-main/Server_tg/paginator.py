import math

class LengthAwarePaginator:
    def __init__(self, items, total, per_page, current_page, base_url=''):
        self.items = items
        self.total = total
        self.per_page = per_page
        self.current_page = current_page
        self.base_url = base_url

    @property
    def last_page(self):
        return math.ceil(self.total / self.per_page)

    def get_links(self):
        return {
            "first": f"{self.base_url}?page=1",
            "last": f"{self.base_url}?page={self.last_page}",
            "prev": f"{self.base_url}?page={self.current_page - 1}" if self.current_page > 1 else None,
            "next": f"{self.base_url}?page={self.current_page + 1}" if self.current_page < self.last_page else None
        }

    def to_dict(self):
        return {
            "data": [item.to_dict() for item in self.items],  # assumes model has .to_dict()
            "total": self.total,
            "per_page": self.per_page,
            "current_page": self.current_page,
            "last_page": self.last_page,
            "links": self.get_links()
        }
