from app import db
from datetime import datetime

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(80))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self):
        return f'<User {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
        }

class Sample(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(80), nullable=False)
    wavelength = db.Column(db.Integer, nullable=False)
    temperature = db.Column(db.Integer, nullable=False)
    band = db.Column(db.Integer, nullable=False)
    sampling_rate = db.Column(db.Integer, nullable=False)
    filter_time = db.Column(db.String(1), nullable=False)
    added_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    # relationship property for easier access
    user = db.relationship('User', backref=db.backref('samples', lazy=True))

    def __repr__(self):
        return f'<Sample {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'wavelength': self.wavelength,
            'temperature': self.temperature,
            'band': self.band,
            'sampling_rate': self.sampling_rate,
            'filter_time': self.filter_time,
            'added_by': self.added_by,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
        }
