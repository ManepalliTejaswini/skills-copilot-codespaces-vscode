from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from config import Config
import json
from flask_cors import CORS
from datetime import datetime
from paginator import LengthAwarePaginator
from sqlalchemy import desc

db = SQLAlchemy()
migrate = Migrate()

def pagination(page, data, total):
    total = data.count()
    records = data.offset(offset).limit(per_page).all()
    
    paginator = LengthAwarePaginator(records, total, per_page, page, base_url='/methodDataPage')
    return jsonify(paginator.to_dict())

def validator(data):
    errors = []
        
    name = data.get('name')
    if name is None:
        errors.append("name is missing")
    elif not isinstance(name, str) or not name.strip():
        errors.append("name must be a non-blank string")
            
    filter_time = data.get('filter_time')
    if filter_time is None:
        errors.append("filter_time is missing")
    elif filter_time != 'N' and filter_time != 'F' and filter_time != 'S':
        errors.append("filter_time invalid")
            
    added_by = data.get('added_by')
    if added_by is None:
        errors.append("added_by is missing")
    elif added_by != 1:
        errors.append("added_by invalid")

    # Required fields and their ranges
    numeric_fields = {
        'wavelength': (190, 512),
        'temperature': (4, 90),
        'band': (0, 5),
        'sampling_rate': (1, 80),
    }

    for field, (min_val, max_val) in numeric_fields.items():
        value = data.get(field)

        if value is None:
            errors.append(f"{field} is missing")
        elif not (min_val <= value <= max_val):
            errors.append(f"{field} must be between {min_val} and {max_val}")

    return errors

def create_app():
    app = Flask(__name__)
    CORS(app)  # This will enable CORS for all routes and origins
    app.config.from_object(Config)

    db.init_app(app)
    migrate.init_app(app, db)

    from models import User  # import your models here
    from models import Sample  # import your models here
    
    @app.route('/hi', methods=['GET'])
    def data():
        return {"msg": "Hello there"}

    @app.route('/data', methods=['GET'])
    def get_data():
        with open('db.json', 'r') as f:
            data = json.load(f)
        return jsonify(data)
    
    @app.route('/methodData', methods=['GET'])
    def get_samples():
        query = request.args.get('q', '')  # get search query from URL ?q=some_text
        if not query:
            samples = Sample.query.order_by(Sample.updated_at.desc()).all()           # get list of Sample objects
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            response = {
                "status": "success",
                "message": "Data fetched successfully",
                "data": samples_list
            }
            return jsonify(response), 200         # return JSON response
        else:
            samples = Sample.query.filter(Sample.name.ilike(f"%{query}%")).all()
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            response = {
                "status": "success",
                "message": "Data fetched successfully",
                "data": samples_list
            }
            return jsonify(response), 200         # return JSON response

    @app.route('/methodData/<int:id>', methods=['GET'])
    def get_my_sample(id):
        sample = Sample.query.get(id)
        if sample:
            response = {
                    "status": "success",
                    "message": "Record fetched successfully",
                    "data": sample.to_dict()
            }
            return jsonify(response), 200         # return JSON response
        else:
            response = {
                    "status": "fail",
                    "message": "Record not found",
                    "data": ""
            }
            return jsonify(response), 401         # return JSON response

    @app.route('/methodData', methods=['POST'])
    def create_sample():
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400

        data = request.get_json()
        
        errors = validator(data)
        
        if errors:
            return jsonify({
                "status": "fail",
                "message": "Validation failed",
                "errors": errors
            }), 402

        sample = Sample(name=data['name'],wavelength=data['wavelength'],temperature=data['temperature'],band=data['band'],sampling_rate=data['sampling_rate'], filter_time=data['filter_time'],added_by=data['added_by'])
        db.session.add(sample)
        db.session.commit()
        samples = Sample.query.all()           # get list of Sample objects
        samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
        status = "success"
        message = "Record added successfully"
        data = samples_list
        response = {
                "status": status,
                "message": message,
                "data": data
        }
        return jsonify(response), 201
    
    @app.route('/methodData/<int:id>', methods=['PUT'])
    def update_sample(id):
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400

        data = request.get_json()
        
        errors = validator(data)

        if errors:
            return jsonify({
                "status": "fail",
                "message": "Validation failed",
                "errors": errors
            }), 402

        sample = Sample.query.get_or_404(id)
        sample.name = data.get('name', sample.name)
        sample.wavelength = data.get('wavelength', sample.wavelength)
        sample.temperature = data.get('temperature', sample.temperature)
        sample.band = data.get('band', sample.band)
        sample.sampling_rate = data.get('sampling_rate', sample.sampling_rate)
        sample.filter_time = data.get('filter_time', sample.filter_time)
        sample.added_by = data.get('added_by', sample.added_by)
        sample.updated_at = datetime.utcnow()
        db.session.commit()
        samples = Sample.query.all()           # get list of Sample objects
        samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
        response = {
                "status": "success",
                "message": "Record updated successfully",
                "data": samples_list
        }
        return jsonify(response), 201
    
    @app.route('/methodData/<int:id>', methods=['DELETE'])
    def delete_sample(id):
        sample = Sample.query.get(id)
        
        if not sample:
            response = {
                "status": "fail",
                "message": "Record not found",
                "data": ""
            }
            return jsonify(response), 401         # return JSON response
        else:
            db.session.delete(sample)
            db.session.commit()
            samples = Sample.query.all()           # get list of Sample objects
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            response = {
                "status": "success",
                "message": "Record deleted successfully",
                "data": samples_list
            }
            return jsonify(response), 201

    '''
        The following are the routes that support
        Pagination, but still untested
    '''
    
    @app.route('/methodDataPage', methods=['GET'])
    def get_samples_paginated():
        query = request.args.get('q', '')  # get search query from URL ?q=some_text
        page = int(request.args.get('page', 1))
        per_page = 2
        if page:
            offset = (page - 1) * per_page 
        else: 
            offset = 0
    
        if not query and not page:
            samples = Sample.query.order_by(desc(Sample.updated_at)).all()           # get list of Sample objects
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            
            total = Sample.query.count()
            data = samples_list
            
            paginated_results = LengthAwarePaginator(samples, total, per_page, page)
            response = {
                "status": "success",
                "message": "Data fetched successfully",
                "data": paginated_results.to_dict()
            }
            return jsonify(response), 200         # return JSON response
        
        elif not query and page:
            samples = Sample.query.offset(offset).limit(per_page).all()           # get list of Sample objects
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
                        
            total = Sample.query.count()
            data = samples_list
            
            paginated_results = LengthAwarePaginator(samples, total, per_page, page)
            response = {
                "status": "success",
                "message": "Data fetched successfully",
                "data": paginated_results.to_dict()
            }
            return jsonify(response), 200         # return JSON response 
            
        elif query and not page:
            samples = Sample.query.filter(Sample.name.ilike(f"%{query}%")).all()
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            response = {
                "status": "success",
                "message": "Data fetched successfully",
                "data": samples_list
            }
            return jsonify(response), 200         # return JSON response
        
        else:
            page = 1
            offset = 0
            samples = Sample.query.filter(Sample.name.ilike(f"%{query}%")).offset(offset).limit(per_page).all()
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            
            total = Sample.query.count()
            data = samples_list
                         
            paginated_results = LengthAwarePaginator(samples, total, per_page, page)
            response = {
                "status": "success",
                "message": "Data fetched successfully",
                "data": paginated_results.to_dict()
            }
            return jsonify(response), 200         # return JSON response   
        
    @app.route('/methodDataPage/<int:id>', methods=['GET'])
    def get_my_sample_paginated(id):
        sample = Sample.query.get(id)
        if sample:
            response = {
                    "status": "success",
                    "message": "Record fetched successfully",
                    "data": sample.to_dict()
            }
            return jsonify(response), 200         # return JSON response
        else:
            response = {
                    "status": "fail",
                    "message": "Record not found",
                    "data": ""
            }
            return jsonify(response), 401         # return JSON response

    @app.route('/methodDataPage', methods=['POST'])
    def create_sample_paginated():
        if not request.is_json:
            return jsonify({
                "status": "fail",
                "message": "Invalid JSON format"
            }), 400

        data = request.get_json()
        
        errors = validator(data)
        
        if errors:
            return jsonify({
                "status": "fail",
                "message": "Validation failed",
                "errors": errors
            }), 402

        page = int(request.args.get('page', 1))
        per_page = 2
        if page:
            offset = (page - 1) * per_page 
        else: 
            offset = 0
        
        sample = Sample(name=data['name'],wavelength=data['wavelength'],temperature=data['temperature'],band=data['band'],sampling_rate=data['sampling_rate'], filter_time=data['filter_time'],added_by=data['added_by'])
        db.session.add(sample)
        db.session.commit()
        samples = Sample.query.order_by(desc(Sample.updated_at)).all()           # get list of Sample objects
        samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
        status = "success"
        message = "Record added successfully"
        
        total = Sample.query.count()
        data = samples_list
                        
        paginated_results = LengthAwarePaginator(samples, total, per_page, page)
            
        response = {
            "status": status,
            "message": message,
            "data": paginated_results.to_dict()
        }
        return jsonify(response), 201
    
    @app.route('/methodDataPage/<int:id>', methods=['PUT'])
    def update_sample_paginated(id):
        if not request.is_json:
            return jsonify({
                "status": "fail",
                "message": "Invalid JSON format"
            }), 400

        data = request.get_json()
        
        errors = validator(data)

        if errors:
            return jsonify({
                "status": "fail",
                "message": "Validation failed",
                "errors": errors
            }), 402

        page = int(request.args.get('page', 1))
        per_page = 2
        if page:
            offset = (page - 1) * per_page 
        else: 
            offset = 0
        
        sample = Sample.query.get(id)
        if not sample:
            response = {
                "status": "fail",
                "message": "Record not found",
                "data": ""
            }
            return jsonify(response), 401         # return JSON response
        else:
            sample.name = data.get('name', sample.name)
            sample.wavelength = data.get('wavelength', sample.wavelength)
            sample.temperature = data.get('temperature', sample.temperature)
            sample.band = data.get('band', sample.band)
            sample.sampling_rate = data.get('sampling_rate', sample.sampling_rate)
            sample.filter_time = data.get('filter_time', sample.filter_time)
            sample.added_by = data.get('added_by', sample.added_by)
            sample.updated_at = datetime.utcnow()
            db.session.commit()
            samples = Sample.query.order_by(desc(Sample.updated_at)).all()           # get list of Sample objects
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            
            total = Sample.query.count()
            data = samples_list
                            
            paginated_results = LengthAwarePaginator(samples, total, per_page, page)
        
            response = {
                    "status": "success",
                    "message": "Record updated successfully",
                    "data": paginated_results.to_dict()
            }
            return jsonify(response), 201
    
    @app.route('/methodDataPage/<int:id>', methods=['DELETE'])
    def delete_sample_paginated(id):
        sample = Sample.query.get(id)
        
        if not sample:
            response = {
                "status": "fail",
                "message": "Record not found",
                "data": ""
            }
            return jsonify(response), 401         # return JSON response
        else:
            
            page = int(request.args.get('page', 1))
            per_page = 2
            if page:
                offset = (page - 1) * per_page 
            else: 
                offset = 0
            
            db.session.delete(sample)
            db.session.commit()
            samples = Sample.query.order_by(desc(Sample.updated_at)).all()           # get list of Sample objects
            samples_list = [sample.to_dict() for sample in samples]  # convert each to dict
            
            total = Sample.query.count()
            data = samples_list
                            
            paginated_results = LengthAwarePaginator(samples, total, per_page, page)
        
            response = {
                "status": "success",
                "message": "Record deleted successfully",
                "data": paginated_results.to_dict()
            }
            return jsonify(response), 201

    return app
