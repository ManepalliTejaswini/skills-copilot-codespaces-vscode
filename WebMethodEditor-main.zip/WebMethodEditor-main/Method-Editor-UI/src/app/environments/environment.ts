export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:7057/methodData',
  apiKey: '202508080701211QXBEbnJLMm16VHJTTGl5b2w'
};
