import { environment } from '../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Method } from '../method.model';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private url = `${environment.apiBaseUrl}`;

  private headers = new HttpHeaders({
    'x-api-key': environment.apiKey
  });

  constructor(private http: HttpClient) {}

  // Fetch all samples with optional query, page, and archived flag
  getAll(page: number = 1, q: string = '', showArchived: boolean = false): Observable<any> {
    let params = new HttpParams().set('page', page.toString());

    if (q.trim()) {
      params = params.set('q', q.trim());
    }

    // Add archived query parameter
    params = params.set('archived', showArchived.toString());

    return this.http.get<any>(this.url, {
      params,
      headers: this.headers
    });
  }

  // Add a new sample
  add(m: Method): Observable<Method> {
    return this.http.post<Method>(this.url, m, {
      headers: this.headers
    });
  }

  // Update an existing sample
  update(m: Method): Observable<Method> {
    return this.http.put<Method>(`${this.url}/${m.id}`, m, {
      headers: this.headers
    });
  }

  // Delete a sample
  delete(id: number | undefined): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`, {
      headers: this.headers
    });
  }

  // Get versions of a specific record
  getVersions(recordId: number, page: number): Observable<any> {
    let params = new HttpParams()
      .set('id', recordId.toString())
      .set('page', page.toString()); 

    return this.http.get<any>(`${this.url}/methodDataVersions`, {
      headers: this.headers,
      params
    });
  }
}
