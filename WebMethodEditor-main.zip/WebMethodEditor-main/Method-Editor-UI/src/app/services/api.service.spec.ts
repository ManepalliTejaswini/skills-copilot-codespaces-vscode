import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { Method } from '../method.model';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private url = 'http://localhost:3000/spectralData';

  constructor(private http: HttpClient) {}

  getPaged(page: number, limit: number): Observable<{ data: Method[]; total: number }> {
    const params = new HttpParams()
      .set('_page', page)
      .set('_limit', limit);

    return this.http.get<Method[]>(this.url, {
      observe: 'response',
      params
    }).pipe(
      map(resp => ({
        data: resp.body || [],
        total: parseInt(resp.headers.get('X-Total-Count') || '0', 10)
      }))
    );
  }

  add(m: Method): Observable<Method> {
    return this.http.post<Method>(this.url, m);
  }

  update(m: Method): Observable<Method> {
    return this.http.put<Method>(`${this.url}/${m.id}`, m);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`);
  }
}
