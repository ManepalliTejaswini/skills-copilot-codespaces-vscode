import { Component, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SliderModule } from 'primeng/slider';
import { ButtonModule } from 'primeng/button';
import { Method } from './method.model';
import { SelectModule } from 'primeng/select';

@Component({
  selector: 'method-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    SliderModule,
    ButtonModule,
    SelectModule
  ],
  styleUrls: ['./app.component.scss'],
  templateUrl: './method-form.html',
})
export class MethodFormComponent {
  @Input() model!: Method;
  @Input() isEditMode = false;
  @Output() save = new EventEmitter<Method>();
  @Output() cancel = new EventEmitter<void>();

  filterOptions: ('Normal' | 'Slow' | 'Fast')[] = ['Normal', 'Slow', 'Fast'];
  samplingRates = [
  { label: '1', value: 1 },
  { label: '2', value: 2 },
  { label: '5', value: 5 },
  { label: '10', value: 10 },
  { label: '20', value: 20 },
  { label: '40', value: 40 },
  { label: '80', value: 80 },
  { label: '160', value: 160 }
];

isFilterTimeValid(): boolean {
  return /^[a-zA-Z]+$/.test(this.model.filter_time || '');
}
  help() {
    alert(`Fill fields within allowed range:
• Wavelength: 190–512
• Temperature: 4–90
• Band: 0–5
• Sampling Rate: 1–80
• Filter Time: choose one from toggle.`);
  }

  @HostListener('document:keydown.f1', ['$event'])
  onF1(ev: KeyboardEvent) {
    ev.preventDefault();
    this.help();
  }

  onCancel(form: any) {
    form.resetForm(); // This resets template-driven form
    this.cancel.emit();
  }
}