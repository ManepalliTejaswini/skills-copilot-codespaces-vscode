import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

import { ApiService } from './services/api.service';
import { MethodFormComponent } from './method-form';
import { Method } from './method.model';
import { VersionTableComponent } from './version-table';

/* PrimeNG */
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { TooltipModule } from 'primeng/tooltip';
import { DropdownModule } from 'primeng/dropdown';
import { SkeletonModule } from 'primeng/skeleton';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'dashboard',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    TableModule,
    ButtonModule,
    InputTextModule,
    DialogModule,
    ConfirmDialogModule,
    ToastModule,
    TooltipModule,
    DropdownModule,
    SkeletonModule,
    InputSwitchModule,
    MethodFormComponent,
    VersionTableComponent
  ],
  providers: [ConfirmationService, MessageService],
  styleUrls: ['./app.component.scss'],
  template: `
    <p-toast></p-toast>
    <p-confirmDialog></p-confirmDialog>

    <div class="dashboard_header">Method Displayer Dashboard</div>

    <div class="table_header">
      <div class="left" style="display: flex; align-items: center; gap: 1.5rem;">
        <input
          pInputText
          [formControl]="searchControl"
          placeholder="Search..."
          aria-label="Search methods"
          class="search_sample_input"
        />

        <!-- PrimeNG Switch -->
        <span class="archived-switch big-switch">
          <p-inputSwitch [(ngModel)]="showArchived" (onChange)="onArchivedToggle($event)"></p-inputSwitch>
          Show Archived Samples
        </span>
      </div>
      <div class="right">
        <button
          pButton
          class="add_new_sample_button p-button-rounded p-button-success"
          icon="pi pi-plus"
          label="Add Sample"
          (click)="openForm()"
          tooltipPosition="left"
        ></button>
      </div>
    </div>

    <div class="table_container">
      <p-table
        [value]="data()"
        [paginator]="true"
        [rows]="rowsPerPage"
        [totalRecords]="totalItems"
        [lazy]="true"
        [loading]="loading()"
        [first]="(currentPage() - 1) * rowsPerPage"
        (onLazyLoad)="onPageChange($event)"
        class="compact-table"
      >
        <ng-template pTemplate="header">
          <tr>
            <th class="table_header_content">Name</th>
            <th class="table_header_content">Wavelength</th>
            <th class="table_header_content">Temperature</th>
            <th class="table_header_content">Band</th>
            <th class="table_header_content">Sampling</th>
            <th class="table_header_content">Filter Time</th>
            <th class="table_header_content">Actions</th>
          </tr>
        </ng-template>

        <ng-template pTemplate="body" let-m>
          <tr>
            <td class="table_row_content">{{ m.name }}</td>
            <td class="table_row_content">{{ m.wavelength }}</td>
            <td class="table_row_content">{{ m.temperature }}</td>
            <td class="table_row_content">{{ m.band }}</td>
            <td class="table_row_content">{{ m.sampling_rate }}</td>
            <td class="table_row_content">{{ filterTimeMap[m.filter_time] || m.filter_time }}</td>
            <td class="table_row_content">
              <!-- Always visible -->
              <button 
                pButton 
                class="p-button-text text-purple" 
                icon="pi pi-eye" 
                (click)="viewVersion(m)" 
                pTooltip="View Version">
              </button>

              <!-- Only if NOT archived -->
              <ng-container *ngIf="!m.is_archived">
                <button 
                  pButton 
                  class="p-button-text text-primary" 
                  icon="pi pi-copy" 
                  (click)="copy(m)" 
                  pTooltip="Copy record">
                </button>
                <button 
                  pButton 
                  class="p-button-text text-success" 
                  icon="pi pi-pencil" 
                  (click)="edit(m)" 
                  pTooltip="Edit record">
                </button>
                <button 
                  pButton 
                  class="p-button-text text-danger" 
                  icon="pi pi-trash" 
                  (click)="confirmDelete(m)" 
                  pTooltip="Delete record">
                </button>
              </ng-container>
            </td>
          </tr>
        </ng-template>

        <ng-template pTemplate="loadingBody">
          <tr *ngFor="let _ of [1,2,3,4,5]">
            <td colspan="7"><p-skeleton height="1.5rem"></p-skeleton></td>
          </tr>
        </ng-template>
      </p-table>
    </div>

    <p-dialog
      header="{{ current().id ? 'Edit Method' : 'Add Method' }}"
      [(visible)]="showForm"
      modal
      [style]="{ width: '450px' }"
    >
      <method-form
        [model]="current()"
        [isEditMode]="current().id !== undefined"
        (save)="onSave($event)"
        (cancel)="showForm = false"
      ></method-form>
    </p-dialog>

    <version-table
       [visible]="showVersionsDialog"
       [recordId]="selectedRecordId"
       [onCloseCallback]="closeVersionDialog"
    ></version-table>
  `
})
export class DashboardComponent {
  private api = inject(ApiService);
  private toast = inject(MessageService);
  private confirm = inject(ConfirmationService);

  data = signal<Method[]>([]);
  currentPage = signal(1);
  totalItems = 0;
  rowsPerPage = 2;
  loading = signal(false);

  searchControl = new FormControl('');
  showArchived = false; // Tracks switch state
  showForm = false;
  current = signal<Method>(this.empty());

  filterTimeMap: Record<string, string> = {
    N: 'Normal',
    S: 'Slow',
    F: 'Fast'
  };

  ngOnInit() {
    this.load();
    this.searchControl.valueChanges
      .pipe(debounceTime(500))
      .subscribe(() => {
        this.currentPage.set(1);
        this.load(1);
      });
  }

  empty(): Method {
    return {
      name: '',
      wavelength: 190,
      temperature: 4,
      band: 0,
      sampling_rate: 1,
      filter_time: 'Normal',
      added_by: 1
    };
  }

  load(page: number = 1) {
    this.loading.set(true);
    const q = this.searchControl.value || '';

    this.api.getAll(page, q, this.showArchived).subscribe(res => {
      const result = res.data;
      this.data.set(result.data);
      this.totalItems = result.total;
      this.currentPage.set(result.current_page);
      this.rowsPerPage = result.per_page;
      this.loading.set(false);
    });
  }

  onArchivedToggle(event: any) {
    this.currentPage.set(1);
    this.load(1);
  }

  onPageChange(event: any) {
    const page = Math.floor(event.first / event.rows) + 1;
    this.currentPage.set(page);
    this.load(page);
  }

  openForm(m?: Method) {
    const reverseMap: Record<string, Method['filter_time']> = {
      N: 'Normal',
      S: 'Slow',
      F: 'Fast'
    };

    const mapped = m ? {
      ...m,
      filter_time: reverseMap[m.filter_time] || m.filter_time
    } : this.empty();

    this.current.set(mapped);
    this.showForm = true;
  }

  edit(m: Method) {
    this.openForm(m);
  }

  copy(m: Method): void {
    const copied: Method = {
      ...m,
      id: undefined,
      name: `${m.name} - copy`
    };
    this.openForm(copied);
  }

  showVersionsDialog = false;
  selectedRecordId: number | null = null;

  closeVersionDialog = () => {
    this.showVersionsDialog = false;
    this.selectedRecordId = null;
  };

  viewVersion(record: Method) {
    this.selectedRecordId = record.id || null;
    this.showVersionsDialog = true;
  }

  confirmDelete(m: Method) {
    this.confirm.confirm({
      acceptButtonStyleClass: 'p-confirmdialog-accept-button',
      rejectButtonStyleClass: 'p-confirmdialog-reject-button',
      message: `Delete "${m.name}"?`,
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => this.delete(m)
    });
  }

  private delete(m: Method) {
    if (m.id) {
      this.api.delete(m.id).subscribe(() => {
        this.load(this.currentPage());
        this.toast.add({
          severity: 'success',
          summary: 'Deleted',
          detail: `${m.name} removed.`,
          life: 2000
        });
      });
    }
  }

  onSave(m: Method) {
    const filterMap: Record<string, string> = {
      Normal: 'N',
      Slow: 'S',
      Fast: 'F'
    };

    const payload: Method = {
      ...m,
      filter_time: filterMap[m.filter_time] as Method['filter_time'],
      added_by: 1
    };

    const req = payload.id ? this.api.update(payload) : this.api.add(payload);

    req.subscribe(() => {
      this.load(this.currentPage());
      this.showForm = false;
      this.toast.add({
        severity: 'success',
        summary: 'Saved',
        detail: `Method ${payload.id ? 'updated' : 'added'} successfully.`,
        life: 2000
      });
    });
  }
}
