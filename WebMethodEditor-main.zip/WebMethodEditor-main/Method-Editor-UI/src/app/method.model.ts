export interface Method {
  id?: number;
  name: string;
  wavelength: number;
  temperature: number;
  band: number;
  sampling_rate: number;
  filter_time: 'Normal' | 'Slow' | 'Fast' | 'N' | 'S' | 'F';
  added_by: number;
}
