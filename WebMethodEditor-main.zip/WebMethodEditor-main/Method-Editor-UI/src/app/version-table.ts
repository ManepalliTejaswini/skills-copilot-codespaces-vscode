import { Component, Input, OnInit, OnChanges, SimpleChanges, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { ApiService } from './services/api.service';

@Component({
  selector: 'version-table',
  standalone: true,
  imports: [CommonModule, TableModule, DialogModule],
  template: `
    <p-dialog
      header="Versions Table"
      [(visible)]="visible"
      modal
      [style]="{ width: '100vw', height: '100vh' }"
      [closable]="true"
      [resizable]="true"
      [draggable]="true"
      (onHide)="onClose()"
    >
      <!-- Smaller Sample ID section with same size as column header -->
      <div style="padding: 0.5em; font-weight: bold; font-size: 1rem; margin-bottom: 10px; text-align: center;">
        Sample ID: {{ recordId }}
      </div>

      <p-table
        [value]="versions()"
        [paginator]="true"
        [rows]="rows"
        [totalRecords]="totalVersions()"
        [lazy]="true"
        (onLazyLoad)="loadVersions($event)"
        [scrollable]="true"
        scrollHeight="calc(90vh - 150px)"
        styleClass="custom-table"
      >
        <ng-template pTemplate="header">
          <tr>
            <th>Operation</th>
            <th>Date & Time</th>
            <th>Name</th>
            <th>Wavelength</th>
            <th>Temperature</th>
            <th>Band</th>
            <th>Sampling Rate</th>
            <th>Filter Time</th>
            <th>Updated By</th>
          </tr>
        </ng-template>

        <ng-template pTemplate="body" let-version>
          <tr>
            <td>{{ version.operation }}</td>
            <td>{{ version.dateTime | date: 'short' }}</td>
            <td>{{ version.name }}</td>
            <td>{{ version.wavelength }}</td>
            <td>{{ version.temperature }}</td>
            <td>{{ version.band }}</td>
            <td>{{ version.samplingRate }}</td>
            <td>{{ version.filterTime }}</td>
            <td>{{ version.updatedBy }}</td>
          </tr>
        </ng-template>

        <ng-template pTemplate="emptymessage">
          <tr>
            <td [attr.colspan]="9" style="text-align: center; padding: 2em;">
              No records found.
            </td>
          </tr>
        </ng-template>
      </p-table>
    </p-dialog>
  `,
  styles: [`
    /* Slightly reduced row height */
    :host ::ng-deep .custom-table tbody tr {
      height: 35px !important;
    }

    :host ::ng-deep .custom-table tbody tr td {
      padding-top: 7px !important;
      padding-bottom: 7px !important;
      vertical-align: middle !important;
    }

    /* Styling for the Sample ID section */
    :host ::ng-deep .sample-id-container {
      font-size: 1rem;
      font-weight: bold;
      text-align: center;
      margin-bottom: 10px;
      padding: 0.5em;
      background-color: #f5f5f5;
      border-radius: 5px;
    }
  `]
})
export class VersionTableComponent implements OnInit, OnChanges {
  @Input() visible = false;
  @Input() recordId: number | null = null;
  @Input() sampleId: number | null = null;  // currently not used here but available
  @Input() onCloseCallback: () => void = () => {};

  private api = inject(ApiService);

  versions = signal<any[]>([]);
  totalVersions = signal(0);
  rows = 10;

  ngOnInit() {
    if (this.visible && this.recordId) {
      this.loadVersions({ first: 0, rows: this.rows });
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if ((changes['recordId'] || changes['visible']) && this.recordId && this.visible) {
      this.loadVersions({ first: 0, rows: this.rows });
    }
  }

  loadVersions(event: any) {
    if (!this.recordId) return;

    const page = Math.floor(event.first / event.rows) + 1;

    this.api.getVersions(this.recordId, page).subscribe({
      next: res => {
        const dataArray = res?.data?.data ?? [];

        const mappedData = dataArray.map((v: any) => ({
          operation:
            v.operation_type === 1 ? 'Update' :
            v.operation_type === 2 ? 'Delete' :
            'Create',
          dateTime: new Date(v.updated_at),
          name: v.name,
          wavelength: v.wavelength,
          temperature: v.temperature,
          band: v.band,
          samplingRate: v.sampling_rate,
          filterTime: v.filter_time,
          updatedBy: v.updated_by
        }));

        this.versions.set(mappedData);
        this.totalVersions.set(res?.data?.total ?? dataArray.length);
      },
      error: err => {
        console.error('Error fetching versions:', err);
        this.versions.set([]);
        this.totalVersions.set(0);
      }
    });
  }

  onClose() {
    this.versions.set([]);
    this.totalVersions.set(0);
    this.recordId = null;
    this.sampleId = null;
    this.onCloseCallback();
  }
}
