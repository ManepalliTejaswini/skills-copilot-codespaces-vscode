using Method_Editor_API.Models;
using Microsoft.EntityFrameworkCore;

namespace Method_Editor_API.DBContext
{
    public class MethodDataDB : DbContext
    {
        public MethodDataDB(DbContextOptions<MethodDataDB> options) : base(options) { }
        public DbSet<SampleEntity> samples { get; set; }
        public DbSet<UserEntity> users { get; set; }
        public DbSet<VersionSamplesEntity>version_samples { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SampleEntity>(entity =>
            {
                entity.Property(e => e.added_by)
                      .HasDefaultValue(0);
                entity.Property(e => e.is_archived)
                      .HasDefaultValue(false) 
                      .IsRequired();
                entity.HasOne<UserEntity>()
                      .WithMany()
                      .HasForeignKey(e => e.added_by)
                      .OnDelete(DeleteBehavior.Restrict);
            });
            modelBuilder.Entity<VersionSamplesEntity>(entity =>
            {                
                entity.HasOne<SampleEntity>()
                      .WithMany()
                      .HasForeignKey(e => e.sample_id)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne<UserEntity>()
                      .WithMany()
                      .HasForeignKey(e => e.updated_by)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            base.OnModelCreating(modelBuilder);
        }

    }
}
