﻿using Azure.Identity;
using Method_Editor_API.DBContext;
using Method_Editor_API.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using Method_Editor_API.CommonClass;
using static Microsoft.Extensions.Logging.EventSource.LoggingEventSource;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace Method_Editor_API.Controllers
{
    [ApiController]
    [Route("methodData")]
    public class MethodDataController : ControllerBase
    {
        private readonly MethodDataDB _methodDbcontext;

        public MethodDataController(MethodDataDB db)
        {
            _methodDbcontext = db;
        }
        //get the sample by using sample id
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetSample_ID([FromRoute] int id)
        {
          
            try
            {
                var sample = await _methodDbcontext.samples.FirstOrDefaultAsync(s => s.id == id);
                if (sample != null)
                {
                    return Ok(new { data = sample, message = "Record found successfully", status = 200 });                   
                }
                else
                {
                    return NotFound(new { message = "Record not found", status = 401 });
                }
               
            }
            catch (SqlException)
            {
                return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }
           
        }
        // methodData?q={searchTerm}/page={page_number} 
        [HttpGet()]
        public async Task<IActionResult> GetSamples(string? q = null,int page = 1,bool archived = false )
        {
            try
            {
                int pageSize = 10;
                var query = _methodDbcontext.samples.AsQueryable();
                if (!string.IsNullOrEmpty(q))
                {
                    query = query.Where(s => s.name.Contains(q));
                }
               query = query.Where(s => s.is_archived == archived).OrderByDescending(s => s.updated_at);
                int totalRecords = await query.CountAsync();
                var records = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
                int lastPage = (int)Math.Ceiling((double)totalRecords / pageSize);
                string baseUrl = $"{Request.Scheme}://{Request.Host}{Request.Path}";
                var responseData = new
                {
                    current_page = page,
                    data = records,
                    last_page = lastPage,
                    links = new
                    {
                        first = $"{baseUrl}?page=1",
                        last = $"{baseUrl}?page={lastPage}",
                        next = page < lastPage ? $"{baseUrl}?page={page + 1}" : null,
                        prev = page > 1 ? $"{baseUrl}?page={page - 1}" : null
                    },
                    per_page = pageSize,
                    total = totalRecords
                };
                if (records != null)
                {
                    return Ok(new { data = responseData, message = "Records found successfully", status = 200 });
                }
                else
                {
                    return Ok(new { data = "", message = "Data fetched successfully", status = 200 });
                }
            }
            catch (SqlException)
            {
                return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }

        }
        //update the sample in Database
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSample([FromRoute] uint id, [FromBody] SampleEntity updatedSample)
        {
            using var transaction = await _methodDbcontext.Database.BeginTransactionAsync();
            try
            {
                var existingSamples = await _methodDbcontext.samples.FindAsync(id);
                if (existingSamples != null)
                {
                    existingSamples.is_archived = false;
                    var user = HttpContext.Items["User"] as UserEntity;

                    if (user != null)
                    {
                        var versionsample = new VersionSamplesEntity
                        {
                            operation_type = 1,
                            sample_id = existingSamples.id,
                            name = existingSamples.name,
                            wavelength = existingSamples.wavelength,
                            temperature = existingSamples.temperature,
                            band = existingSamples.band,
                            sampling_rate = existingSamples.sampling_rate,
                            filter_time = existingSamples.filter_time,
                            updated_by = user.id,
                            updated_at = DateTime.Now
                        };
                        _methodDbcontext.version_samples.Add(versionsample);
                         await _methodDbcontext.SaveChangesAsync();
                        existingSamples.name = updatedSample.name;
                        existingSamples.wavelength = updatedSample.wavelength;
                        existingSamples.temperature = updatedSample.temperature;
                        existingSamples.band = updatedSample.band;
                        existingSamples.sampling_rate = updatedSample.sampling_rate;
                        existingSamples.filter_time = updatedSample.filter_time;
                        existingSamples.added_by = user.id;
                        existingSamples.updated_at = DateTime.Now;
                    }
                    _methodDbcontext.samples.Update(existingSamples);
                    await transaction.CommitAsync();
                    var records = await _methodDbcontext.version_samples.Where(v => v.sample_id == id).OrderByDescending(v => v.updated_at).ToListAsync();
                    await _methodDbcontext.SaveChangesAsync();

                    return Ok(new { data = existingSamples, message = "Record updated successfully", status = 201 });
                }
                else
                {
                     await transaction.RollbackAsync();
                    return NotFound(new { status = 401, message = "Record not found" });

                }
            }
            catch (SqlException)
            {
                return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }
        }
        //Delete the data from record
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSample([FromRoute] uint id)
        {
            using var transaction = await _methodDbcontext.Database.BeginTransactionAsync();
            try
            {
                var existingSamples = await _methodDbcontext.samples.FindAsync(id);
                var user = HttpContext.Items["User"] as UserEntity;
                if (existingSamples != null && user != null)
                {                  
                    var versionsamples = new VersionSamplesEntity
                    {
                        operation_type = 2,
                        name = existingSamples.name,
                        sample_id = existingSamples.id,
                        wavelength = existingSamples.wavelength,
                        temperature = existingSamples.temperature,
                        band = existingSamples.band,
                        sampling_rate = existingSamples.sampling_rate,
                        filter_time = existingSamples.filter_time,
                        updated_at = DateTime.Now,
                        updated_by = user.id
                    };
                    existingSamples.is_archived = true;
                    existingSamples.updated_at = DateTime.Now;
                    _methodDbcontext.samples.Update(existingSamples);
                    _methodDbcontext.version_samples.Add(versionsamples);
                    await transaction.CommitAsync();
                    var records = await _methodDbcontext.version_samples.Where(v => v.sample_id == id).OrderByDescending(v => v.updated_at).ToListAsync();
                    await _methodDbcontext.SaveChangesAsync();
                    return Ok(new { message = "Record deleted successfully", status = 201 });
                }
                else
                {
                    return NotFound(new { message = "Record not found", status = 401 });
                }
            }
            catch (SqlException)
            {
                await transaction.RollbackAsync();
                return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }
        }
        //Adding  user 
        [HttpPost("addUser")]
        public async Task<IActionResult> AddUser([FromBody] UserRequest user)
        {           
            try
            {
                var existingmail = await _methodDbcontext.users.FirstOrDefaultAsync(u => u.email == user.email);
                if ((IsValidEmail(user.email)) || (existingmail == null))

                {
                    if (string.IsNullOrEmpty(user.name))
                    {
                        return NotFound(new { status = 401, message = "Data missing" });
                    }
                    var User = new UserEntity()
                    {
                        name = user.name,
                        email = user.email,
                        created_at = DateTime.Now,
                        updated_at = DateTime.Now,
                        api_key = "Mcejiwrjiqjrjqojrororrokrokqor",
                        password = Security.GenerateRandomPassword(),
                    };
                    _methodDbcontext.users.Add(User);
                    await _methodDbcontext.SaveChangesAsync();
                    var apiKey = Security.GenerateRandomApiKey(User.id.ToString());
                    if (apiKey != null)
                    {
                        User.api_key = apiKey.Result;

                    }
                    _methodDbcontext.users.Update(User);
                    await _methodDbcontext.SaveChangesAsync();
                    return Ok(new { data = User, message = "User added successfully", status = 200 });
                   
                }
                else
                {
                    return NotFound(new { status = 403, message = "Invalid mail Id" });

                }
            }
            catch (SqlException)
            {
                return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }
        }
        // Email validation method
        private bool IsValidEmail(string email)
        {
            try
            {
                var mailId = new System.Net.Mail.MailAddress(email);
                return mailId.Address == email;
            }
            catch
            {
                return false;

            }
        }
        //Adding sample
        [HttpPost]
        public async Task<IActionResult> AddSample([FromBody] SampleEntity sample)
        {
            try
            {
                var userExists = HttpContext.Items["User"] as UserEntity;
               
                if (userExists != null)
                {
                    sample.added_by = userExists.id;
                    sample.created_at = DateTime.Now;
                    sample.updated_at = DateTime.Now;
                    sample.is_archived = false;
                    _methodDbcontext.samples.Add(sample);
                    await _methodDbcontext.SaveChangesAsync();
                    return Ok(new { data = sample, message = "Record added successfully", status = 201 });
                }
                else
                {
                    return NotFound(new { status = 403, message = "Invalid user" });
                }
            }
            catch (SqlException)
            {
                    return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }
        }

        //methodDataversions/id
        [HttpGet("methodDataVersions/{id}")]
        public async Task<IActionResult> GetMethodDataVersionID([FromRoute] int id)
        {
            try
            {
                if (id <= 0)
                {
                    return NotFound(new { message = " ID is required.", status = 401 });
                }
                else
                {
                    var versionsampleId = await _methodDbcontext.version_samples.Where(v => v.sample_id == id).OrderByDescending(v => v.updated_at).ToListAsync();
                    if (versionsampleId != null)
                    {
                        return Ok(new { data = versionsampleId, message = "Records found successfully", status = 200 });
                    }
                    else
                    {
                        return NotFound(new { message = $"No version samples found for sample_id {id}", status = 401 });
                    }
                }
            }
            catch (SqlException)
            {
                return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }
        }

        //methodDataVersions/{id}?page={page_number}&type={operationType}&from={fromDate}&to={toDate} 
        [HttpGet("methodDataVersions")]
        public async Task<IActionResult> GetMethodDataVersions( int id, int page = 1, string? operationtype = null, DateTime? from = null, DateTime? to = null)
        {
            try
            {
                int pageSize = 10;
                var query = _methodDbcontext.version_samples.AsQueryable();
                if (id <= 0)
                {
                    return NotFound(new { message = "ID is required", status = 401 });
                }
                else
                {
                    
                     query = query.Where(v => v.sample_id == id);
                    if (!string.IsNullOrEmpty(operationtype))
                    {
                        if (int.TryParse(operationtype, out int operationType))
                        {
                            query = query.Where(v => v.operation_type == operationType);
                        }
                    }
                    if (from.HasValue)
                    {
                        query = query.Where(v => v.updated_at >= from.Value);
                    }
                    if (to.HasValue)
                    {
                        query = query.Where(v => v.updated_at <= to.Value);
                    }
                    query = query.OrderByDescending(v => v.updated_at);
                    int totalRecords = await query.CountAsync();
                    var records = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
                    int lastPage = (int)Math.Ceiling((double)totalRecords / pageSize);

                    var responseData = new
                    {
                        current_page = page,
                        data = records,
                        last_page = lastPage,
                        per_page = pageSize,
                        total = totalRecords
                    };
                    return Ok(new { data = responseData, message = "Version data fetched successfully", status = 200 });
                }

            }
            catch (SqlException)
            {
                return NotFound(new { message = "Temporary Error. Please try again after some time.", status = 405 });
            }
        }

    }
}

