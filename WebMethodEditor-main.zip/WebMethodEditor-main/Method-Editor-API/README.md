﻿1. **Pre-requisites**

		1.1 Visual Studio2022
		1.2 ASP.NET Core Web API
		1.3 .NET SDK 8.0
		1.4 SQL Express 2022
1. **Packages to be Install**
      
		1. Microsoft Entity Framework core package
		2. Microsoft.EntityFrameworkCore.SqlServer	
		3. Microsoft.EntityFrameworkCore.Design
		4. Microsoft.EntityFrameworkCore.Tools
		5. Swashbuckle.AspNetCore	
	To Install Packages
		<pre>dotnet add package packagename</pre>
	To Restore package
		<pre>dotnet restore</pre>
1. **Deployment**	
	 git clone https://github.com/SyamkumarMphasis/WebMethodEditor 
1. **Migrations**
		
-	Create Database - Add connection string in appsettings.json file
<pre>"ConnectionStrings": {
  "DefaultConnection": "Server= servername; Database=DBName;Trusted_Connection=True;"
}
</pre>
-	Add Configuration - It registers the database DBcontext with the .NET dependency injection (DI) container and to configure it to use SQL Server as the database provider.
	
<pre> builder.Services.AddDbContext<DBContextName>(options =>
options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));</pre>
-	Migration(run through cmd or bash)	
	
Install dotnet EF package : 
<pre>dotnet tool install --global dotnet-ef</pre>
- To  Run Migrations :
<pre>dotnet ef database update </pre>
5. **ToStart Project**
<pre>cd projectpath

dotnet run</pre>
