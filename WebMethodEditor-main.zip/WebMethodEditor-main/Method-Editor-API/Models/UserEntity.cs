﻿using System.ComponentModel.DataAnnotations;

namespace Method_Editor_API.Models
{
    public class UserEntity
    {
        public uint id { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 10, ErrorMessage = "Name must be between 10 and 100 characters.")]
        public string? name { get; set; }
        [Required]
        [StringLength(100)]
        public string email { get; set; } = null!;

        [Required]
        [StringLength(255, MinimumLength = 8, ErrorMessage = "Password invalid. Minimum length should be 8 characters.")]
        public string password { get; set; } = null!;
        [Required]
        [StringLength(255, MinimumLength = 32)]
        public string api_key { get; set; } = null!;
        public DateTime created_at { get; set; }       
        public DateTime updated_at { get; set; }
    }
}
