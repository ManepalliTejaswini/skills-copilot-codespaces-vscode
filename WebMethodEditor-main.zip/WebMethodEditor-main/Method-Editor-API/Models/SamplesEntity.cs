using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Method_Editor_API.Models
{
    public class SampleEntity
    {
        public uint id { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 10, ErrorMessage = "Name must be between 10 and 100 characters.")]
        public required string name { get; set; }

        [Required]
        [Range(190, 512, ErrorMessage = "Wavelength must be between 190 and 512.")]
        public uint wavelength { get; set; }

        [Required]
        [Range(4, 90, ErrorMessage = "Temperature must be between 4 and 90.")]
        public uint temperature { get; set; }

        [Required]
        [Range(0, 5, ErrorMessage = "Band must be between 0 and 5.")]
        public uint band { get; set; }

        [Required]
        [RegularExpression("^(1|2|5|10|20|40|80|160)$",ErrorMessage = "Sampling Rate must be one of the values: 1, 2, 5, 10, 20, 40, 80, 160")]
        public uint sampling_rate { get; set; }

        [Required]
        [RegularExpression("^(S|N|F)$", ErrorMessage = "Invalid Value of Filter time. It must be either Slow or Normal or Fast.")]
        public string? filter_time { get; set; }
        public uint added_by { get; set; }     
        public DateTime created_at { get; set; }        
        public DateTime updated_at { get; set; }
        
        public bool is_archived { get; set; } 
    }
}
