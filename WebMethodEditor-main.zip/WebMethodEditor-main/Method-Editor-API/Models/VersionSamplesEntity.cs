﻿using System.ComponentModel.DataAnnotations;

namespace Method_Editor_API.Models
{
    public class VersionSamplesEntity
    {
        public uint id { get; set; }
        [Required]
       
        [MaxLength(1)]
        public uint operation_type { get; set; }
        [Required]
        public uint? sample_id { get; set; }
        public required string? name { get; set; }
        public uint wavelength { get; set; }
        public uint temperature { get; set; }
        public uint band { get; set; }
        public uint sampling_rate { get; set; }
        public string? filter_time { get; set; } = "N";
        [Required]
        [Range(1, int.MaxValue)]
        public uint updated_by { get; set; } = 0;
        [Required]
        public DateTime updated_at { get; set; } = DateTime.Now;

    }
}
