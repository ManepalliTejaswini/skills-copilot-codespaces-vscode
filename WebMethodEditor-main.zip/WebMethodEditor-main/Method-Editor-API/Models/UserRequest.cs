﻿namespace Method_Editor_API.Models
{
    public class UserRequest
    {
        public string? name { get; set; }
        public string email { get; set; } = string.Empty;    
    }
}
