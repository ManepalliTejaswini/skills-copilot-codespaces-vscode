﻿using Azure.Core;
using Azure.Identity;
using BCrypt.Net;
using Method_Editor_API.DBContext;
using Method_Editor_API.Models;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Method_Editor_API.CommonClass
{  
    public static class Security
    {
     
        public static string GenerateRandomPassword(int length = 32)
        {
            try
            {
                const string validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*";
                var random = new Random();
                string randompassword = string.Empty;

                for (int i = 0; i < length; i++)
                {
                    randompassword += validChars[random.Next(validChars.Length)];
                }
                string hashpwd = HashPassword(randompassword);
                string password = hashpwd.Substring(0, length);
                return password;
            }
            catch (Exception ex)
            {
                return(ex.Message);
            }          
        }
        public static  Task<string> GenerateRandomApiKey(string? userId)
        {
            try
            {
                const string validchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
                var random = new Random();
                int totallength = 32;
                string timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
                string prefix = timestamp + userId;
                int remaininglength = totallength - prefix.Length;
                string remainingchar = string.Empty;
                for (int i = 0; i < remaininglength; i++)
                {
                     remainingchar+=validchars[random.Next(validchars.Length)];
                }
                string randomKey = prefix + remainingchar;
                byte[] bytes = Encoding.UTF8.GetBytes(randomKey);
                string apikey = Convert.ToBase64String(bytes);                                        
                return Task.FromResult(apikey);
            }
            catch (Exception ex)
            {
                return Task.FromResult(ex.Message);
            }
           
        }
        public static string HashPassword(string plainPassword)
        {
            try
            {
                return BCrypt.Net.BCrypt.HashPassword(plainPassword);
            }
            catch (Exception ex)
            {
                return(ex.Message);
            }           
        }

        public static bool VerifyPassword(string plainPassword, string hashedPassword)
        {
            try
            {
                return BCrypt.Net.BCrypt.Verify(plainPassword, hashedPassword);
            }
            catch (Exception)
            { 
             return(false);  
            }           
        }       
    }
    public  class ApiKeyMiddleware
    {
        private readonly RequestDelegate _next;
        private const string API_KEY_HEADER = "X-API-KEY";

        public ApiKeyMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context, MethodDataDB dbContext)
        {
            try
            {
                var path = context.Request.Path.Value?.ToLower();
                if (path?.Contains("/adduser") ==true)
                {
                    await _next(context);
                    return;
                }
                var apiKey = context.Request.Headers[API_KEY_HEADER].FirstOrDefault();
                if (string.IsNullOrEmpty(apiKey))
                {
                    context.Response.StatusCode = 403;
                    await context.Response.WriteAsync("Missing Api key");
                    return;
                }
                else
                {
                    var user = await dbContext.users.FirstOrDefaultAsync(u => u.api_key == apiKey.ToString());
                    if (user == null)
                    {
                        context.Response.StatusCode = 403;
                        await context.Response.WriteAsync("Invalid Api key");
                        return;
                    }
                    context.Items["User"] = user;
                    await _next(context);
                }
                
            }
            catch (Exception)
            {
                context.Response.StatusCode = 500; 
                await context.Response.WriteAsync("Internal Server Error,Something went wrong.");
                return;
            }
        }
    }
  
}
