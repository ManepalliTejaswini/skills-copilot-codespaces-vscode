﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Method_Editor_API.Migrations
{
    /// <inheritdoc />
    public partial class Updatedatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    password = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    api_key = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    created_at = table.Column<DateTime>(type: "datetime2", nullable: false),
                    updated_at = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_users", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "samples",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    wavelength = table.Column<long>(type: "bigint", nullable: false),
                    temperature = table.Column<long>(type: "bigint", nullable: false),
                    band = table.Column<long>(type: "bigint", nullable: false),
                    sampling_rate = table.Column<long>(type: "bigint", nullable: false),
                    filter_time = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    added_by = table.Column<long>(type: "bigint", nullable: false, defaultValue: 0L),
                    created_at = table.Column<DateTime>(type: "datetime2", nullable: false),
                    updated_at = table.Column<DateTime>(type: "datetime2", nullable: false),
                    is_archived = table.Column<bool>(type: "bit", nullable: false, defaultValue: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_samples", x => x.id);
                    table.ForeignKey(
                        name: "FK_samples_users_added_by",
                        column: x => x.added_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "version_samples",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    operation_type = table.Column<long>(type: "bigint", maxLength: 1, nullable: false),
                    sample_id = table.Column<long>(type: "bigint", nullable: false),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    wavelength = table.Column<long>(type: "bigint", nullable: false),
                    temperature = table.Column<long>(type: "bigint", nullable: false),
                    band = table.Column<long>(type: "bigint", nullable: false),
                    sampling_rate = table.Column<long>(type: "bigint", nullable: false),
                    filter_time = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    updated_by = table.Column<long>(type: "bigint", nullable: false),
                    updated_at = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_version_samples", x => x.id);
                    table.ForeignKey(
                        name: "FK_version_samples_samples_sample_id",
                        column: x => x.sample_id,
                        principalTable: "samples",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_version_samples_users_updated_by",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_samples_added_by",
                table: "samples",
                column: "added_by");

            migrationBuilder.CreateIndex(
                name: "IX_version_samples_sample_id",
                table: "version_samples",
                column: "sample_id");

            migrationBuilder.CreateIndex(
                name: "IX_version_samples_updated_by",
                table: "version_samples",
                column: "updated_by");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "version_samples");

            migrationBuilder.DropTable(
                name: "samples");

            migrationBuilder.DropTable(
                name: "users");
        }
    }
}
